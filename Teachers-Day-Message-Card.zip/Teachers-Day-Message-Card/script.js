document.addEventListener("DOMContentLoaded", () => {
  const music = document.getElementById("bg-music");
  const toggle = document.getElementById("music-toggle");
  const card = document.querySelector(".card");

  // Initial animation glow
  card.style.boxShadow = "0 0 50px rgba(255, 255, 255, 0.12)";
  setTimeout(() => {
    card.style.transition = "box-shadow 1.8s ease";
    card.style.boxShadow = "0 0 28px rgba(255, 255, 255, 0.45)";
  }, 800);

  // Some browsers block autoplay with sound. Try to play; if blocked, update button text.
  music.play().then(() => {
    toggle.textContent = "🔊 Music On";
  }).catch(() => {
    toggle.textContent = "🔇 Music Off (Tap to enable)";
    music.pause();
  });

  // Handle music toggle
  toggle.addEventListener("click", () => {
    if (music.paused) {
      music.play();
      toggle.textContent = "🔊 Music On";
    } else {
      music.pause();
      toggle.textContent = "🔇 Music Off";
    }
  });
});
