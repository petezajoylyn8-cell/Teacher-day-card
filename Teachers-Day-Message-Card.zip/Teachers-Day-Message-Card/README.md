# Teachers' Day Message Card

A personalized Teachers' Day message card dedicated to **Mr. Randy Bello**, created by **Joylyn Pardeño Peteza**.

## Description
A modern and animated web-based greeting card with soft background music to celebrate Teachers’ Day.
Built with **HTML, CSS, and JavaScript**.

## Features
- Animated floating photo  
- Fade-in text effects  
- Soft background music with mute/unmute button  
- Responsive and elegant design  

## Files included
- `index.html` — main card layout  
- `style.css` — styling and animations  
- `script.js` — interactivity (music control and glow)  
- `teacher.jpg` — placeholder teacher image (replace with your own photo for best result)  
- `music.wav` — short silent placeholder audio (replace with a soft piano instrumental file named `music.mp3` or `music.wav`)

## How to use
1. Download and extract the project folder.  
2. Replace `teacher.jpg` with the actual teacher photo (keep the same filename).  
3. Replace `music.wav` with your chosen soft piano instrumental (`music.mp3` or `music.wav`).  
4. Open `index.html` in any browser.  
5. If autoplay is blocked by the browser, click the Music button to enable sound.

## Note about autoplay
Many mobile browsers block autoplay for audio. If sound doesn't start automatically, just tap the **Music** button.

## Credits
Created by **Joylyn Pardeño Peteza**
For **Mr. Randy Bello** — Teachers' Day 2025
